/*                    /--------------------------\
 *                    |       Bitmap Image        |
 *                    |           to              |
 *                    |       C-style array       |
 *                    \---------------------------/
 *                       2015-02-01, Coert Vonk
 *
 * Convert a bitmap (.bmp) image to its black/white representation in C-style
 * hex values.
 *
 * Purpose:
 *   I used it with the gfxstaff.cpp in the Android Pitch Detector project.
 *
 * Implementation:
 *   
 * Compiling:
 *   Visual Studio, C++, console application project.
 *
 * Libraries used:
 *   Uses the EasyBMP Cross-Platform Windows Bitmap Library 1.06 published under
 *   the (revised/modified BSD License).  See http://easybmp.sourceforge.net
 */


#include "EasyBMP.h"  // download library from http://easybmp.sourceforge.net
using namespace std;

int
_luminance( RGBApixel const c )
{
	return (int)(0.299 * c.Red + 0.587 * c.Green + 0.114 * c.Blue);
}

bool
_isBlack( RGBApixel const c )
{
	return _luminance( c ) < 128;
}

void
_printHex( unsigned char const b )
{
	static int count = 0;
	int comma = count != 0;
	int newLine = (count % 16 == 0);

	printf( "%s%s0x%02X", comma ? "," : "",
		newLine ? "\n    " : comma ? " " : "",
		b );
	count++;
}

int
main( int argc, char* argv[] )
{
	if ( argc < 2 ) {
		printf( "Missing file name.  For example:\n  %s fname.BMP\n", argv[0] );
		return 1;
	}

	 BMP input;
	 input.ReadFromFile(argv[1]);

	 int byteCount = 0;

	 printf(
		 "struct _symbol_t {  // uses GNU C style Zero Length array\n"
		 "    unsigned int width;\n"
		 "    unsigned int height;\n"
		 "    unsigned char bitmap[];\n"
		 "} _symbol = { %d, %d, {", input.TellWidth(), input.TellHeight() );

	 unsigned char hex = 0;

	 for ( int y = 0; y < input.TellHeight(); y++ ) {
		 for ( int x = 0; x < input.TellWidth(); x++) {

			 int const pix = _isBlack( input.GetPixel( x, y ) );
			 //printf( "%d", pix );

			 hex = (hex << 1) | (pix ? 1 : 0);

			 if ( ++byteCount % 8 == 0 ) {
				 _printHex( hex );
				 hex = 0x00;
			 }

		 }
	 }
	 if ( byteCount % 8 != 0 ) {
		 hex = hex << ((8 - (byteCount % 8)) % 8);
		 _printHex( hex );
	 }
	 printf( "}\n};\n" );
	 return 0;
}
